//DOM ready
window.addEventListener('load', init);

/**
 * Initialize application
 */
function init()
{

}
